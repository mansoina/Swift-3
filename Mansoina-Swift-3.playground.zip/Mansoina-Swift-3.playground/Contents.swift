import UIKit

//=====================================>>
// =======Computer Class=========>>

class Computer {
    private var brand: String
    private var processor: String
    private var ram: Int
    
    init(brand: String, processor: String, ram: Int) {
        self.brand = brand
        self.processor = processor
        self.ram = ram
    } // init
    
    // getter(s)
    func displaySpecs() {
        print("Brand: \(self.brand) Processor: \(self.processor) RAM: \(self.ram)GB")
    }
    func getBrand() -> String {
        return self.brand
    }
    func getProcessor() -> String {
        return self.processor
    }
    func getRam() -> Int {
        return self.ram
    }
}

//=====================================>>
// =======Laptop Class=========>>
class Laptop: Computer {
    private var isTouchscreen: Bool
    
    init(brand: String, processor: String, ram: Int, isTouchscreen: Bool) {
        self.isTouchscreen = isTouchscreen
        super.init(brand: brand, processor: processor, ram: ram)
    }
    
    // getter(s)
    override func displaySpecs() {
        print("Brand: \(super.getBrand()) Processor: \(super.getProcessor()) RAM: \(super.getRam())GB")
    }
    
    func typeOfScreen() {
        if self.isTouchscreen {
            print("Yes this laptop is touchscreen.")
        } else {
            print("No this is not touchscreen. You need a new laptop!")
        }
    }
} // Laptop


//=====================================>>
// =======Desktop Class=========>>
class Desktop: Computer {
    private var hasDedicatedGPU: Bool
    
    init(brand: String, processor: String, ram: Int, hasDedicatedGPU: Bool) {
        self.hasDedicatedGPU = hasDedicatedGPU
        super.init(brand: brand, processor: processor, ram: ram)
    }
    
    // getter(s)
    override func displaySpecs() {
        print("Brand: \(super.getBrand()) Processor: \(super.getProcessor()) RAM: \(super.getRam())GB")
    }
   
    func requirementGPU() {
        if self.hasDedicatedGPU {
            print("Yes this laptop has dedicated GPU.")
        } else {
            print("No this does not have dedicated GPU.")
        }
    }
} // Desktop


//=====================================>>
// =======Server Class=========>>
class Server: Computer {
   private var rackUnits: Int
    
    init(brand: String, processor: String, ram: Int, rackUnits: Int) {
        self.rackUnits = rackUnits
        super.init(brand: brand, processor: processor, ram: ram)
    }
    
    // getter(s)
    override func displaySpecs() {
        print("Brand: \(super.getBrand()), Processor: \(super.getProcessor()), RAM: \(super.getRam())GB")
        print("Rack Units: \(rackUnits)")
        
    }
}

//===================================>>
// ======= Laptop Testing =======>>

var macbook: Laptop = Laptop(brand: "Apple", processor: "M1", ram: 16, isTouchscreen: false)

macbook.displaySpecs()
macbook.typeOfScreen()
print()

//===================================>>
// ======= Desktop Testing =======>>

var lenovo: Desktop = Desktop(brand: "Lenovo", processor: "Intel i9", ram: 32, hasDedicatedGPU: true)

lenovo.displaySpecs()
lenovo.requirementGPU()
print()

//===================================>>
// ======= Server Testing =======>>

var hpServer: Server = Server(brand: "HP", processor: "Xeon", ram: 64, rackUnits: 4)

hpServer.displaySpecs()
print()
